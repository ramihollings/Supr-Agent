import fs from 'fs';
import path from 'path';

export interface AgentIdentityProfile {
  name: string;
  role: string;
  permissionTier: string;
  type: string;
  systemPrompt: string;
  tools: string[];
  injectedSkills?: string;
  memoryContext?: string;
}

const AGENTS_DIR = path.resolve(process.cwd(), '.agents');

/**
 * Ensures the .agents directory exists.
 */
function ensureAgentsDir() {
  if (!fs.existsSync(AGENTS_DIR)) {
    fs.mkdirSync(AGENTS_DIR, { recursive: true });
  }
}

/**
 * Formats a clean filename based on the agent's name.
 */
function getAgentFilePath(name: string): string {
  const safeName = name.toLowerCase().replace(/[^a-z0-9]/g, '_');
  return path.join(AGENTS_DIR, `${safeName}.md`);
}

/**
 * Creates or overwrites an Identification .md file for a sub-agent.
 */
export function writeIdentityProfile(profile: AgentIdentityProfile) {
  ensureAgentsDir();
  const filePath = getAgentFilePath(profile.name);

  const markdownContent = `---
name: ${profile.name}
role: ${profile.role}
type: ${profile.type}
permission_tier: ${profile.permissionTier}
tools: [${profile.tools.map(t => `"${t}"`).join(', ')}]
---

# Identity
You are ${profile.name}, acting as the ${profile.role} within the Supr orchestration framework.
Your operational clearance is **${profile.permissionTier}**.

# Directives
${profile.systemPrompt}

# Operational Constraints
- Adhere strictly to the Supr Neo-Brutalist communication style.
- Request approval for actions exceeding your permission tier.

${profile.injectedSkills ? `# Acquired Skills & Rules\n${profile.injectedSkills}\n` : ''}
${profile.memoryContext ? `# Compressed Memory Context\n<agentmemory>\n${profile.memoryContext}\n</agentmemory>\n` : ''}
`;

  fs.writeFileSync(filePath, markdownContent, 'utf-8');
  return filePath;
}

/**
 * Deletes an agent's Identification .md file upon termination.
 */
export function deleteIdentityProfile(name: string) {
  const filePath = getAgentFilePath(name);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
}


/**
 * Loaded identity profile. Same shape that `writeIdentityProfile`
 * produces, but rebuilt from disk by `loadIdentityProfile`.
 */
export interface LoadedIdentityProfile extends AgentIdentityProfile {
  bodyMarkdown: string;
  loadedAt: string;
  sourcePath: string;
}

/**
 * Parse the YAML frontmatter + markdown body of an identity .md file.
 * The runtime uses this to pull a real, persona-shaped system prompt
 * for each sub-agent instead of the hard-coded boilerplate. The
 * parser is intentionally minimal -- one key/value per line, no
 * nested structures -- because the writer in this same file is the
 * only producer and the format is internal.
 */
export function parseIdentityMarkdown(source: string, fallbackName: string): AgentIdentityProfile {
  const profile: AgentIdentityProfile = {
    name: fallbackName,
    role: 'Generalist',
    permissionTier: 'Observe',
    type: 'temporary',
    systemPrompt: '',
    tools: [],
  };
  if (!source) return profile;

  const fmMatch = source.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
  if (!fmMatch) {
    return { ...profile, systemPrompt: source.trim() };
  }
  const [, fm, body] = fmMatch;
  const fields: Record<string, string> = {};
  for (const line of fm.split('\n')) {
    const m = line.match(/^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$/);
    if (m) fields[m[1]] = m[2].trim();
  }
  if (fields.name) profile.name = fields.name;
  if (fields.role) profile.role = fields.role;
  if (fields.permission_tier) profile.permissionTier = fields.permission_tier;
  if (fields.type) profile.type = fields.type;
  if (fields.tools) {
    try {
      const parsed = JSON.parse(fields.tools.replace(/'/g, '"'));
      if (Array.isArray(parsed)) profile.tools = parsed.map((t) => String(t));
    } catch {
      profile.tools = [];
    }
  }

  // The body is the system prompt: everything from `# Directives` to
  // the next major section. Fall back to the full body if we can't
  // isolate the directive block.
  const directivesMatch = body.match(/# Directives\n([\s\S]*?)(?:\n# |$)/);
  profile.systemPrompt = (directivesMatch ? directivesMatch[1] : body).trim();
  return profile;
}

/**
 * Read an identity .md from disk and return a `LoadedIdentityProfile`.
 * Returns null if the file is missing, in which case the caller
 * should fall back to the hard-coded Agent_Actions row persona.
 */
export function loadIdentityProfile(name: string): LoadedIdentityProfile | null {
  const filePath = getAgentFilePath(name);
  if (!fs.existsSync(filePath)) return null;
  const raw = fs.readFileSync(filePath, 'utf-8');
  const profile = parseIdentityMarkdown(raw, name);
  return {
    ...profile,
    bodyMarkdown: raw,
    loadedAt: new Date().toISOString(),
    sourcePath: filePath,
  };
}

/**
 * Bulk loader: returns the loaded identity profile for every .md in
 * `.agents/`. Used by the context assembler at session start so the
 * runtime has a single map of (agent name) -> persona.
 */
export function loadAllIdentityProfiles(): Record<string, LoadedIdentityProfile> {
  ensureAgentsDir();
  const out: Record<string, LoadedIdentityProfile> = {};
  for (const file of fs.readdirSync(AGENTS_DIR)) {
    if (!file.endsWith('.md')) continue;
    const raw = fs.readFileSync(path.join(AGENTS_DIR, file), 'utf-8');
    const baseName = file.replace(/\.md$/, '');
    const profile = parseIdentityMarkdown(raw, baseName);
    out[profile.name] = {
      ...profile,
      bodyMarkdown: raw,
      loadedAt: new Date().toISOString(),
      sourcePath: path.join(AGENTS_DIR, file),
    };
  }
  return out;
}

