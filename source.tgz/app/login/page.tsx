"use client";

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';

function LoginPageContent() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSecured, setIsSecured] = useState<boolean | null>(null);
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const res = await fetch('/api/auth/status');
        if (res.ok) {
          const data = await res.json();
          setIsSecured(data.secured);
        }
      } catch (err) {
        console.error("Failed to check auth status:", err);
      }
    };
    checkStatus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const endpoint = isSecured === false ? '/api/auth/setup' : '/api/auth/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        // Redirect to original page or home
        const redirectUrl = searchParams.get('callbackUrl') || '/';
        window.location.href = redirectUrl;
      } else {
        setError(data.error || 'Invalid credentials');
      }
    } catch (err) {
      setError('Connection failed. Please check the network.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isSecured === null) {
    return (
      <div className="fixed inset-0 w-screen h-screen bg-surface-container flex flex-col items-center justify-center p-4 md:p-8 overflow-y-auto">
        <div className="max-w-md w-full bg-background border-4 border-primary shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] p-8 text-center my-auto">
          <p className="font-headline font-bold text-sm uppercase text-primary animate-pulse">Checking Node clearance...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 w-screen h-screen bg-surface-container flex flex-col items-center justify-center p-4 md:p-8 selection:bg-primary-container selection:text-on-primary-container overflow-y-auto">
      <div className="max-w-md w-full bg-background border-4 border-primary shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] p-8 relative overflow-hidden my-auto">
        {/* Decorative corner block */}
        <div className="absolute top-0 right-0 bg-tertiary text-on-tertiary font-headline font-bold text-[10px] uppercase px-4 py-1 border-b-2 border-l-2 border-primary tracking-wider">
          {isSecured === false ? 'Setup Node' : 'Security Gate v3.5'}
        </div>

        {/* Logo and Brand */}
        <header className="mb-8 border-b-4 border-primary pb-6 mt-4">
          <div className="flex items-center gap-3">
            <Image src="/supr_logo.svg" alt="Supr Logo" width={48} height={48} className="shrink-0 border-2 border-primary bg-primary-fixed p-1 neo-shadow" />
            <div>
              <h1 className="font-headline text-3xl font-black uppercase tracking-tighter text-primary">Supr</h1>
              <p className="font-body text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Autonomous Supervisor Node</p>
            </div>
          </div>
        </header>

        {/* Info Box */}
        <div className="bg-surface-container-high border-2 border-primary p-4 mb-6 relative">
          <span className="material-symbols-outlined text-secondary absolute top-4 right-4 text-xl">
            {isSecured === false ? 'lock_reset' : 'shield_lock'}
          </span>
          <h2 className="font-headline font-bold uppercase text-xs text-primary mb-1 tracking-wider">
            {isSecured === false ? 'First-Boot Secure Setup' : 'Restricted Workspace'}
          </h2>
          <p className="font-body text-xs text-on-surface-variant font-bold leading-relaxed pr-8">
            {isSecured === false 
              ? 'Configure a master key to secure your autonomous supervisor node. This key will be stored in your database and required for all subsequent sessions.' 
              : 'This supervisor workspace is protected under Governed Autonomy standards. Enter the master access key to establish a secure management session.'
            }
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="password" className="block font-headline text-xs font-bold uppercase text-primary mb-2 tracking-wider">
              {isSecured === false ? 'Create Master Access Key' : 'Master Access Key'}
            </label>
            <div className="relative">
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isSecured === false ? "Enter secure password" : "••••••••••••"}
                className="w-full bg-surface border-4 border-primary px-4 py-3 font-mono text-sm placeholder-on-surface-variant focus:outline-none focus:bg-surface-container-low transition-colors neo-shadow-sm focus:translate-x-0.5 focus:translate-y-0.5 focus:shadow-none"
              />
            </div>
          </div>

          {error && (
            <div className="bg-error-container border-2 border-error p-3 text-xs font-body font-bold text-error uppercase flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">warning</span>
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-primary text-on-primary font-headline font-bold uppercase py-3.5 border-2 border-primary hover:bg-primary-fixed hover:text-primary transition-all duration-100 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] active:translate-x-1 active:translate-y-1 active:shadow-none flex items-center justify-center gap-2 disabled:opacity-50 disabled:pointer-events-none"
          >
            <span className="material-symbols-outlined text-[18px]">
              {isSecured === false ? 'lock' : 'key'}
            </span>
            <span>
              {isLoading 
                ? 'Processing...' 
                : (isSecured === false ? 'Secure Node & Authorize' : 'Authorize Session')
              }
            </span>
          </button>
        </form>

        <footer className="mt-8 text-center border-t-2 border-outline-variant pt-4">
          <p className="font-body text-[10px] text-on-surface-variant uppercase font-bold tracking-wider">
            {isSecured === false ? 'Clearance Level 3 • Initializing Secure Sandbox' : 'Clearance Level 3 • Governed Sandbox enabled'}
          </p>
        </footer>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="fixed inset-0 w-screen h-screen bg-surface-container flex flex-col items-center justify-center p-4 md:p-8 overflow-y-auto">
        <div className="max-w-md w-full bg-background border-4 border-primary shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] p-8 text-center my-auto">
          <p className="font-headline font-bold text-sm uppercase text-primary animate-pulse">Initializing Decryption...</p>
        </div>
      </div>
    }>
      <LoginPageContent />
    </Suspense>
  );
}
