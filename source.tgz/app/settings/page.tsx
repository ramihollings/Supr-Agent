"use client";

import { TopNav } from '@/components/TopNav';
import { useState, useEffect, useRef } from 'react';
import { notifySettingsChanged } from '@/hooks/useSettingsSnapshot';
import { StandardsSection } from '@/components/settings/StandardsSection';
import { PermissionsSection } from '@/components/settings/PermissionsSection';
import { PortabilitySection } from '@/components/settings/PortabilitySection';
import { LLMConfigSection } from '@/components/settings/LLMConfigSection';
import { MemorySection } from '@/components/settings/MemorySection';
import { SkillsLessonsPanel } from '@/components/SkillsLessonsPanel';
import { CompactionPanel } from '@/components/CompactionPanel';
import {
  fetchSettingsAction,
  updateSettingAction,
  fetchMemoryItemsAction,
  purgeMemoryItemsAction,
  addGlobalMemoryItemAction,
  updateMemoryReviewAction,
  fetchDesignProfilesAction,
  applyDesignProfileAction,
  fetchConnectorHealthAction,
  fetchLiveProviderModelsAction,
  testConnectorAction,
  probeDockerAvailabilityAction,
  exportOrganizationAction,
  importOrganizationAction,
  fetchMissionsAction,
  fetchAgentsState
} from '@/app/actions';
import { DEFAULT_BACKUP_MODEL, DEFAULT_MINIMAX_MODEL, PROVIDER_MODEL_OPTIONS, PROVIDER_OPTIONS, defaultModelForProvider } from '@/lib/providers/catalog';

interface MemoryItem {
  id: string;
  key: string;
  value: string;
  type: string;
  scope: string;
  importance: string;
  pinned: boolean;
  reason: string;
  reviewedAt?: string;
  stale: boolean;
  createdAt: string;
}

interface DesignProfile {
  id: string;
  name: string;
  file: string;
  theme: string;
  palette: string;
  mood: string;
  preview: string;
}

interface ConnectorHealth {
  id: string;
  name: string;
  configured: boolean;
  status: string;
  lastChecked: string;
}

const ALLOWED_THEMES = new Set([
  'neo-brutalist',
  'openclaw',
  'dark-saas-hero-with-liquid-glass',
  'aurora-ui',
  'futuristic-ui-glassmorphism',
  '8-bit-retro-terminal',
  'cyber-tribal',
  'minimalist-clean',
  'notion',
  'thevge',
  'ibm-carbon-enterprise',
  'supr-clean'
]);

const ALLOWED_PALETTES = new Set([
  'classic',
  'cyberpunk-neon',
  'nordic-frost',
  'forest-moss',
  'vintage-orange',
  'matrix-digital',
  'sunset-glow',
  'ocean-breeze',
  'royal-velvet',
  'sakura-pastel',
  'minimal-monochrome',
  'desert-cactus',
  'corporate-tech',
  'toxic-spill',
  'warm-autumn',
  'design-notion',
  'design-verge',
]);

function sanitizeTheme(theme: string) {
  return ALLOWED_THEMES.has(theme) ? theme : 'neo-brutalist';
}

function sanitizePalette(palette: string) {
  return ALLOWED_PALETTES.has(palette) ? palette : 'classic';
}

function builtInModelOptionsForProvider(provider: string) {
  return PROVIDER_MODEL_OPTIONS[provider] || [];
}

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState('Operating Mode');
  const [operatingMode, setOperatingMode] = useState('Supervisor');
  const [permissionBoundary, setPermissionBoundary] = useState('governed');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [liveProviderModels, setLiveProviderModels] = useState<Record<string, { label: string; value: string }[]>>({});

  // Global LLM Keys States
  const [globalMinimaxKey, setGlobalMinimaxKey] = useState('');
  const [globalGeminiKey, setGlobalGeminiKey] = useState('');
  const [globalOpenaiKey, setGlobalOpenaiKey] = useState('');
  const [globalAnthropicKey, setGlobalAnthropicKey] = useState('');
  const [globalXaiKey, setGlobalXaiKey] = useState('');
  const [globalOpenrouterKey, setGlobalOpenrouterKey] = useState('');
  const [globalGroqKey, setGlobalGroqKey] = useState('');
  const [globalMistralKey, setGlobalMistralKey] = useState('');
  const [globalDeepseekKey, setGlobalDeepseekKey] = useState('');
  const [globalBackupKey, setGlobalBackupKey] = useState('');
  const [globalBackupUrl, setGlobalBackupUrl] = useState('');
  const [globalBackupModel, setGlobalBackupModel] = useState(DEFAULT_BACKUP_MODEL);
  const [globalBackupName, setGlobalBackupName] = useState('');

  // Role Overrides States
  const [suprProvider, setSuprProvider] = useState('default');
  const [suprKey, setSuprKey] = useState('');
  const [suprModel, setSuprModel] = useState('');
  const [suprUrl, setSuprUrl] = useState('');

  const [codeProvider, setCodeProvider] = useState('default');
  const [codeKey, setCodeKey] = useState('');
  const [codeModel, setCodeModel] = useState('');
  const [codeUrl, setCodeUrl] = useState('');

  const [researchProvider, setResearchProvider] = useState('default');
  const [researchKey, setResearchKey] = useState('');
  const [researchModel, setResearchModel] = useState('');
  const [researchUrl, setResearchUrl] = useState('');

  const [subProvider, setSubProvider] = useState('default');
  const [subKey, setSubKey] = useState('');
  const [subModel, setSubModel] = useState('');
  const [subUrl, setSubUrl] = useState('');

  // Channels States
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [slackEnabled, setSlackEnabled] = useState(false);
  const [discordEnabled, setDiscordEnabled] = useState(false);
  const [telegramEnabled, setTelegramEnabled] = useState(false);
  const [socialEnabled, setSocialEnabled] = useState(false);
  const [dockerAvailable, setDockerAvailable] = useState(false);
  const [dockerLastProbe, setDockerLastProbe] = useState('');
  const [remoteExecutionEnabled, setRemoteExecutionEnabled] = useState(false);
  const [remoteExecutionHost, setRemoteExecutionHost] = useState('');

  const [telegramToken, setTelegramToken] = useState('718290382:AAFlk1829aB...');
  const [telegramWebhookSecret, setTelegramWebhookSecret] = useState('');
  const [telegramChatId, setTelegramChatId] = useState('-100192830182');
  const [twitterHandle, setTwitterHandle] = useState('@supr_orchestrator');
  const [lastBackupAt, setLastBackupAt] = useState<string | null>(null);
  const [isBackingUp, setIsBackingUp] = useState(false);

  // Memory Banks States
  const [memoryItems, setMemoryItems] = useState<MemoryItem[]>([]);
  const [showMemoryModal, setShowMemoryModal] = useState(false);
  const [activeMemoryBank, setActiveMemoryBank] = useState<string>('User');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newImportance, setNewImportance] = useState('Medium');
  const [memorySearch, setMemorySearch] = useState('');
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);

  const modeRef = useRef<HTMLDivElement>(null);
  const permissionsRef = useRef<HTMLDivElement>(null);
  const llmRef = useRef<HTMLDivElement>(null);
  const appearanceRef = useRef<HTMLDivElement>(null);
  const integrationsRef = useRef<HTMLDivElement>(null);
  const memoryRef = useRef<HTMLDivElement>(null);
  const standardsRef = useRef<HTMLDivElement>(null);
  const channelsRef = useRef<HTMLDivElement>(null);
  const portabilityRef = useRef<HTMLDivElement>(null);

  // Portability States
  const [importBundle, setImportBundle] = useState<any>(null);
  const [importStatus, setImportStatus] = useState<'idle' | 'reading' | 'ready' | 'importing'>('idle');
  const [collisions, setCollisions] = useState<{ table: string; count: number; examples: string[] }[]>([]);
  const [confirmOverwrite, setConfirmOverwrite] = useState(false);
  const [importSummary, setImportSummary] = useState<any>(null);
  const [existingMissions, setExistingMissions] = useState<any[]>([]);
  const [existingAgents, setExistingAgents] = useState<any[]>([]);

  // Theme & Appearance States
  const [currentTheme, setCurrentTheme] = useState('neo-brutalist');
  const [currentPalette, setCurrentPalette] = useState('classic');
  const [activeDesignProfile, setActiveDesignProfile] = useState('');
  const [designProfiles, setDesignProfiles] = useState<DesignProfile[]>([]);
  const [connectorHealth, setConnectorHealth] = useState<ConnectorHealth[]>([]);

  // Integration credentials
  const [integrationComposio, setIntegrationComposio] = useState('');
  const [integrationGithub, setIntegrationGithub] = useState('');
  const [integrationSlack, setIntegrationSlack] = useState('');
  const [integrationDiscord, setIntegrationDiscord] = useState('');
  const [integrationGmail, setIntegrationGmail] = useState('');

  // Load settings and memories from SQLite
  useEffect(() => {
    async function loadData() {
      const [settings, memories, missions, agents] = await Promise.all([
        fetchSettingsAction(),
        fetchMemoryItemsAction(),
        fetchMissionsAction(),
        fetchAgentsState()
      ]);
      const [profiles, health] = await Promise.all([
        fetchDesignProfilesAction(),
        fetchConnectorHealthAction(),
      ]);
      setDesignProfiles(profiles);
      setConnectorHealth(health);
      setExistingMissions(missions || []);
      setExistingAgents(agents || []);

      if (settings.appearance_theme) {
        const safeTheme = sanitizeTheme(settings.appearance_theme);
        setCurrentTheme(safeTheme);
        localStorage.setItem('supr_theme', safeTheme);
      }
      if (settings.appearance_palette) {
        const safePalette = sanitizePalette(settings.appearance_palette);
        setCurrentPalette(safePalette);
        localStorage.setItem('supr_palette', safePalette);
      }
      if (settings.active_design_profile) setActiveDesignProfile(settings.active_design_profile);

      if (settings.integrations_composio) setIntegrationComposio(settings.integrations_composio);
      if (settings.integrations_github) setIntegrationGithub(settings.integrations_github);
      if (settings.integrations_slack) setIntegrationSlack(settings.integrations_slack);
      if (settings.integrations_discord) setIntegrationDiscord(settings.integrations_discord);
      if (settings.integrations_gmail) setIntegrationGmail(settings.integrations_gmail);
      if (settings.telegram_webhook_secret) setTelegramWebhookSecret(settings.telegram_webhook_secret);
      if (settings.operating_mode) setOperatingMode(settings.operating_mode);
      if (settings.permission_boundary) setPermissionBoundary(settings.permission_boundary);

      // Global Keys
      if (settings.global_minimax_key) setGlobalMinimaxKey(settings.global_minimax_key);
      if (settings.global_gemini_key) setGlobalGeminiKey(settings.global_gemini_key);
      if (settings.global_openai_key) setGlobalOpenaiKey(settings.global_openai_key);
      if (settings.global_anthropic_key) setGlobalAnthropicKey(settings.global_anthropic_key);
      if (settings.global_xai_key) setGlobalXaiKey(settings.global_xai_key);
      if (settings.global_openrouter_key) setGlobalOpenrouterKey(settings.global_openrouter_key);
      if (settings.global_groq_key) setGlobalGroqKey(settings.global_groq_key);
      if (settings.global_mistral_key) setGlobalMistralKey(settings.global_mistral_key);
      if (settings.global_deepseek_key) setGlobalDeepseekKey(settings.global_deepseek_key);
      if (settings.global_backup_key) setGlobalBackupKey(settings.global_backup_key);
      if (settings.global_backup_url) setGlobalBackupUrl(settings.global_backup_url);
      if (settings.global_backup_model) setGlobalBackupModel(settings.global_backup_model);
      if (settings.global_backup_name) setGlobalBackupName(settings.global_backup_name);

      // Supr Role Override
      const loadedSuprProvider = settings.llm_provider_supr || 'default';
      setSuprProvider(loadedSuprProvider);
      if (settings.llm_key_supr) setSuprKey(settings.llm_key_supr);
      setSuprModel(settings.llm_model_supr || defaultModelForProvider(loadedSuprProvider));
      if (settings.llm_url_supr) setSuprUrl(settings.llm_url_supr);

      // Code Role Override
      const loadedCodeProvider = settings.llm_provider_code || 'default';
      setCodeProvider(loadedCodeProvider);
      if (settings.llm_key_code) setCodeKey(settings.llm_key_code);
      setCodeModel(settings.llm_model_code || defaultModelForProvider(loadedCodeProvider));
      if (settings.llm_url_code) setCodeUrl(settings.llm_url_code);

      // Research Role Override
      const loadedResearchProvider = settings.llm_provider_research || 'default';
      setResearchProvider(loadedResearchProvider);
      if (settings.llm_key_research) setResearchKey(settings.llm_key_research);
      setResearchModel(settings.llm_model_research || defaultModelForProvider(loadedResearchProvider));
      if (settings.llm_url_research) setResearchUrl(settings.llm_url_research);

      // Sub-agents Override
      const loadedSubProvider = settings.llm_provider_sub || 'default';
      setSubProvider(loadedSubProvider);
      if (settings.llm_key_sub) setSubKey(settings.llm_key_sub);
      setSubModel(settings.llm_model_sub || defaultModelForProvider(loadedSubProvider));
      if (settings.llm_url_sub) setSubUrl(settings.llm_url_sub);

      setEmailEnabled(settings.channels_email === 'true');
      setSlackEnabled(settings.channels_slack === 'true');
      setDiscordEnabled(settings.channels_discord === 'true');
      setTelegramEnabled(settings.channels_telegram === 'true');
      setSocialEnabled(settings.channels_social === 'true');
      setDockerAvailable(settings.docker_available === 'true');
      if (settings.docker_last_probe) setDockerLastProbe(settings.docker_last_probe);
      setRemoteExecutionEnabled(settings.remote_execution_enabled === 'true');
      if (settings.remote_execution_host) setRemoteExecutionHost(settings.remote_execution_host);

      if (settings.telegram_token) setTelegramToken(settings.telegram_token);
      if (settings.telegram_chat_id) setTelegramChatId(settings.telegram_chat_id);
      if (settings.twitter_handle) setTwitterHandle(settings.twitter_handle);

      setMemoryItems(memories);
    }
    loadData();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleUpdateSetting = async (key: string, value: string, toastMsg?: string) => {
    const res = await updateSettingAction(key, value);
    if (res.success) {
      // Broadcast to other tabs (and the in-tab chat) so they
      // re-fetch the snapshot. This is the sentinel that
      // useSettingsSnapshot listens for via the 'storage' event.
      notifySettingsChanged();
      if (toastMsg) showToast(toastMsg);
    }
  };

  const modelOptionsForProvider = (provider: string) => {
    const live = liveProviderModels[provider] || [];
    const builtIn = builtInModelOptionsForProvider(provider);
    const seen = new Set<string>();
    return [...live, ...builtIn].filter((model) => {
      if (seen.has(model.value)) return false;
      seen.add(model.value);
      return true;
    });
  };

  const refreshLiveProviderModels = async (provider: string) => {
    if (provider === 'default' || provider === 'openai_compat') return;
    const result = await fetchLiveProviderModelsAction(provider);
    if (!result.success) {
      showToast(result.error || `Could not refresh ${provider} models`);
      return;
    }
    if (result.models.length > 0) {
      setLiveProviderModels((prev) => ({ ...prev, [provider]: result.models }));
      showToast(`Loaded ${result.models.length} live ${provider} models`);
    }
  };

  const selectRoleProvider = (provider: string, setProvider: (value: string) => void, setModel: (value: string) => void) => {
    setProvider(provider);
    const defaultModel = defaultModelForProvider(provider);
    setModel(defaultModel);
    void refreshLiveProviderModels(provider);
  };

  const handleModeChange = (mode: string) => {
    setOperatingMode(mode);
    handleUpdateSetting('operating_mode', mode, `Operating mode set to ${mode} ✓`);
  };

  const handleThemeChange = (theme: string) => {
    const safeTheme = sanitizeTheme(theme);
    theme = safeTheme;
    setCurrentTheme(safeTheme);
    localStorage.setItem('supr_theme', safeTheme);
    const htmlClasses = document.documentElement.className.split(' ');
    const cleanedClasses = htmlClasses.filter(c => !c.startsWith('theme-'));
    document.documentElement.className = `theme-${safeTheme} ` + cleanedClasses.join(' ');
    handleUpdateSetting('appearance_theme', theme, `Theme set to ${theme.toUpperCase()} ✓`);
  };

  const handlePaletteChange = (palette: string) => {
    const safePalette = sanitizePalette(palette);
    palette = safePalette;
    setCurrentPalette(safePalette);
    localStorage.setItem('supr_palette', safePalette);
    const htmlClasses = document.documentElement.className.split(' ');
    const cleanedClasses = htmlClasses.filter(c => !c.startsWith('palette-'));
    document.documentElement.className = `palette-${safePalette} ` + cleanedClasses.join(' ');
    handleUpdateSetting('appearance_palette', palette, `Color Palette set to ${palette.toUpperCase()} ✓`);
  };

  const handleDesignProfileApply = async (profileId: string) => {
    const res = await applyDesignProfileAction(profileId);
    if (res.success && res.profile) {
      const safeTheme = sanitizeTheme(res.profile.theme);
      const safePalette = sanitizePalette(res.profile.palette);
      setActiveDesignProfile(res.profile.id);
      setCurrentTheme(safeTheme);
      setCurrentPalette(safePalette);
      localStorage.setItem('supr_theme', safeTheme);
      localStorage.setItem('supr_palette', safePalette);
      const htmlClasses = document.documentElement.className.split(' ');
      const cleanedClasses = htmlClasses.filter(c => !c.startsWith('theme-') && !c.startsWith('palette-'));
      document.documentElement.className = `theme-${safeTheme} palette-${safePalette} ` + cleanedClasses.join(' ');
      showToast(`Applied ${res.profile.name} design profile`);
    } else {
      showToast(res.error || 'Design profile could not be applied');
    }
  };

  const handleToggleChannel = (channel: string, current: boolean, label: string) => {
    const newVal = !current;
    if (channel === 'email') {
      setEmailEnabled(newVal);
      handleUpdateSetting('channels_email', newVal ? 'true' : 'false', `${label} ${newVal ? 'Enabled' : 'Disabled'} ✓`);
    } else if (channel === 'slack') {
      setSlackEnabled(newVal);
      handleUpdateSetting('channels_slack', newVal ? 'true' : 'false', `${label} ${newVal ? 'Enabled' : 'Disabled'} ✓`);
    } else if (channel === 'discord') {
      setDiscordEnabled(newVal);
      handleUpdateSetting('channels_discord', newVal ? 'true' : 'false', `${label} ${newVal ? 'Enabled' : 'Disabled'} âœ“`);
    } else if (channel === 'telegram') {
      setTelegramEnabled(newVal);
      handleUpdateSetting('channels_telegram', newVal ? 'true' : 'false', `${label} ${newVal ? 'Enabled' : 'Disabled'} ✓`);
    } else if (channel === 'social') {
      setSocialEnabled(newVal);
      handleUpdateSetting('channels_social', newVal ? 'true' : 'false', `${label} ${newVal ? 'Enabled' : 'Disabled'} ✓`);
    }
  };

  const handleAddMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    const res = await addGlobalMemoryItemAction(newKey, newValue, newImportance, activeMemoryBank);
    if (res.success) {
      showToast(`Added memory to ${activeMemoryBank} Bank ✓`);
      setNewKey('');
      setNewValue('');
      const updatedMemories = await fetchMemoryItemsAction();
      setMemoryItems(updatedMemories);
    }
  };

  const handlePurgeBank = async (scope: string) => {
    if (confirm(`Are you sure you want to purge all memories in the ${scope} bank?`)) {
      const res = await purgeMemoryItemsAction(scope);
      if (res.success) {
        showToast(`${scope} bank purged successfully ✓`);
        const updatedMemories = await fetchMemoryItemsAction();
        setMemoryItems(updatedMemories);
      }
    }
  };

  const refreshMemories = async () => {
    const updatedMemories = await fetchMemoryItemsAction();
    setMemoryItems(updatedMemories);
  };

  const handleMemoryReview = async (id: string, updates: { pinned?: boolean; reviewed?: boolean }) => {
    const res = await updateMemoryReviewAction(id, updates);
    if (res.success) {
      showToast(updates.reviewed ? 'Memory marked reviewed' : 'Memory pin updated');
      await refreshMemories();
    } else {
      showToast('Memory update failed');
    }
  };

  const handleConnectorTest = async (connectorId: string, name: string) => {
    const res = await testConnectorAction(connectorId);
    showToast(`${name}: ${res.status}`);
    setConnectorHealth(await fetchConnectorHealthAction());
  };

  const handleDockerProbe = async () => {
    showToast('Checking Docker availability...');
    const res = await probeDockerAvailabilityAction();
    setDockerAvailable(!!res.available);
    setDockerLastProbe(new Date().toISOString());
    showToast(res.available ? 'Docker sandbox is available' : `Docker unavailable: ${res.detail || 'probe failed'}`);
  };

  const handleExportDatabase = async () => {
    setIsBackingUp(true);
    showToast("Generating backup\u2026");
    try {
      const res = await exportOrganizationAction();
      if (res.success && res.data) {
        const blob = new Blob([res.data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `supr_scrubbed_backup_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setLastBackupAt(new Date().toISOString());
        showToast("Scrubbed organization backup downloaded successfully \u2713");
      } else {
        showToast(res.error || "Failed to export organization backup.");
      }
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleImportFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus('reading');
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const bundle = JSON.parse(text);

        if (!bundle || bundle.version !== '1.0.0' || !bundle.data) {
          showToast("Unsupported backup format. Version must be 1.0.0.");
          setImportStatus('idle');
          return;
        }

        const foundCollisions: typeof collisions = [];

        // 1. Check settings collisions
        if (Array.isArray(bundle.data.settings)) {
          const matchingSettings = bundle.data.settings.filter((s: any) => s.value !== '[SCRUBBED]');
          if (matchingSettings.length > 0) {
            foundCollisions.push({
              table: 'Settings',
              count: matchingSettings.length,
              examples: matchingSettings.slice(0, 3).map((s: any) => s.key),
            });
          }
        }

        // 2. Check missions collisions
        if (Array.isArray(bundle.data.missions)) {
          const existingIds = new Set(existingMissions.map((m: any) => m.id));
          const matchingMissions = bundle.data.missions.filter((m: any) => existingIds.has(m.id));
          if (matchingMissions.length > 0) {
            foundCollisions.push({
              table: 'Missions',
              count: matchingMissions.length,
              examples: matchingMissions.slice(0, 3).map((m: any) => m.title),
            });
          }
        }

        // 3. Check agents collisions
        if (Array.isArray(bundle.data.agents)) {
          const existingIds = new Set(existingAgents.map((a: any) => a.id));
          const matchingAgents = bundle.data.agents.filter((a: any) => existingIds.has(a.id));
          if (matchingAgents.length > 0) {
            foundCollisions.push({
              table: 'Agents',
              count: matchingAgents.length,
              examples: matchingAgents.slice(0, 3).map((a: any) => a.name),
            });
          }
        }

        setCollisions(foundCollisions);
        setImportBundle(bundle);
        setImportStatus('ready');
      } catch (err) {
        showToast("Invalid JSON file uploaded.");
        setImportStatus('idle');
      }
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = async () => {
    if (!importBundle) return;
    setImportStatus('importing');
    try {
      const res = await importOrganizationAction(JSON.stringify(importBundle), { allowOverwrite: confirmOverwrite });
      if (res.success && res.imported) {
        setImportSummary(res.imported);
        showToast("Database backup successfully restored ✓");
        setImportStatus('idle');
        setImportBundle(null);
        setCollisions([]);
        setConfirmOverwrite(false);
        // Reload settings, memories, missions, and agents
        const [settings, memories, missions, agents] = await Promise.all([
          fetchSettingsAction(),
          fetchMemoryItemsAction(),
          fetchMissionsAction(),
          fetchAgentsState()
        ]);
        setMemoryItems(memories);
        setExistingMissions(missions || []);
        setExistingAgents(agents || []);
      } else {
        if (res.collisions) setCollisions(res.collisions);
        showToast(res.error || "Restoration failed.");
        setImportStatus('ready');
      }
    } catch (err: any) {
      showToast(err.message || "Restoration failed.");
      setImportStatus('ready');
    }
  };

  const visibleMemoryItems = memoryItems
    .filter(item => item.scope === activeMemoryBank)
    .filter(item => !showPinnedOnly || item.pinned)
    .filter(item => {
      const q = memorySearch.trim().toLowerCase();
      return !q || `${item.key} ${item.value} ${item.reason}`.toLowerCase().includes(q);
    });

  const scrollToSection = (section: string, ref: React.RefObject<HTMLDivElement | null>) => {
    setActiveSection(section);
    ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const providerKeyControls = [
    { label: 'OpenAI API Key', key: 'global_openai_key', value: globalOpenaiKey, setter: setGlobalOpenaiKey, placeholder: 'sk-...' },
    { label: 'Anthropic API Key', key: 'global_anthropic_key', value: globalAnthropicKey, setter: setGlobalAnthropicKey, placeholder: 'sk-ant-...' },
    { label: 'xAI API Key', key: 'global_xai_key', value: globalXaiKey, setter: setGlobalXaiKey, placeholder: 'xai-...' },
    { label: 'OpenRouter API Key', key: 'global_openrouter_key', value: globalOpenrouterKey, setter: setGlobalOpenrouterKey, placeholder: 'sk-or-...' },
    { label: 'Groq API Key', key: 'global_groq_key', value: globalGroqKey, setter: setGlobalGroqKey, placeholder: 'gsk_...' },
    { label: 'Mistral API Key', key: 'global_mistral_key', value: globalMistralKey, setter: setGlobalMistralKey, placeholder: '...' },
    { label: 'DeepSeek API Key', key: 'global_deepseek_key', value: globalDeepseekKey, setter: setGlobalDeepseekKey, placeholder: 'sk-...' },
  ];

  // LLMConfigSection helpers. The page owns the state and the
  // setters; the section just dispatches.
  const onChangeGlobalKey = (key: string, value: string) => {
    switch (key) {
      case 'global_minimax_key': setGlobalMinimaxKey(value); break;
      case 'global_gemini_key': setGlobalGeminiKey(value); break;
      case 'global_openai_key': setGlobalOpenaiKey(value); break;
      case 'global_anthropic_key': setGlobalAnthropicKey(value); break;
      case 'global_xai_key': setGlobalXaiKey(value); break;
      case 'global_openrouter_key': setGlobalOpenrouterKey(value); break;
      case 'global_groq_key': setGlobalGroqKey(value); break;
      case 'global_mistral_key': setGlobalMistralKey(value); break;
      case 'global_deepseek_key': setGlobalDeepseekKey(value); break;
    }
  };
  const onChangeBackupField = (field: 'name' | 'model' | 'url' | 'key', value: string) => {
    if (field === 'name') setGlobalBackupName(value);
    else if (field === 'model') setGlobalBackupModel(value);
    else if (field === 'url') setGlobalBackupUrl(value);
    else setGlobalBackupKey(value);
  };
  const onChangeRoleField = (role: 'supr' | 'code' | 'research' | 'sub', field: 'provider' | 'key' | 'model' | 'url', value: string) => {
    if (field === 'provider') {
      if (role === 'supr') setSuprProvider(value);
      else if (role === 'code') setCodeProvider(value);
      else if (role === 'research') setResearchProvider(value);
      else setSubProvider(value);
    } else if (field === 'key') {
      if (role === 'supr') setSuprKey(value);
      else if (role === 'code') setCodeKey(value);
      else if (role === 'research') setResearchKey(value);
      else setSubKey(value);
    } else if (field === 'model') {
      if (role === 'supr') setSuprModel(value);
      else if (role === 'code') setCodeModel(value);
      else if (role === 'research') setResearchModel(value);
      else setSubModel(value);
    } else {
      if (role === 'supr') setSuprUrl(value);
      else if (role === 'code') setCodeUrl(value);
      else if (role === 'research') setResearchUrl(value);
      else setSubUrl(value);
    }
  };
  const onSelectRoleProvider = (provider: string, role: 'supr' | 'code' | 'research' | 'sub') => {
    if (role === 'supr') selectRoleProvider(provider, setSuprProvider, setSuprModel);
    else if (role === 'code') selectRoleProvider(provider, setCodeProvider, setCodeModel);
    else if (role === 'research') selectRoleProvider(provider, setResearchProvider, setResearchModel);
    else selectRoleProvider(provider, setSubProvider, setSubModel);
  };
  const onSaveGlobalKey = (key: string, value: string, label: string) => {
    void handleUpdateSetting(key, value, label);
  };
  const handleSaveComposioBridge = () => handleUpdateSetting('integrations_composio', integrationComposio, 'Composio bridge key saved ✓');

  const [composioTestResult, setComposioTestResult] = useState<{
    state: 'idle' | 'testing' | 'ok' | 'error';
    elapsedMs?: number;
    appCount?: number;
    firstApps?: Array<{ key: string; name: string }>;
    error?: string;
  }>({ state: 'idle' });
  const handleTestComposioBridge = async () => {
    setComposioTestResult({ state: 'testing' });
    try {
      const res = await fetch('/api/composio/test', { method: 'POST' });
      const data = await res.json().catch(() => ({}));
      if (data?.ok) {
        setComposioTestResult({
          state: 'ok',
          elapsedMs: data.elapsedMs,
          appCount: data.appCount,
          firstApps: data.firstApps,
        });
      } else {
        setComposioTestResult({
          state: 'error',
          elapsedMs: data?.elapsedMs,
          error: data?.error || `HTTP ${res.status}`,
        });
      }
    } catch (err: any) {
      setComposioTestResult({ state: 'error', error: err.message || String(err) });
    }
  };
  const onSaveBackupConfig = async () => {
    // Going through handleUpdateSetting ensures the cross-tab
    // settings sentinel is broadcast on every save, so the chat
    // re-fetches the snapshot in the same tab as well.
    await Promise.all([
      handleUpdateSetting('global_backup_name', globalBackupName),
      handleUpdateSetting('global_backup_model', globalBackupModel),
      handleUpdateSetting('global_backup_url', globalBackupUrl),
      handleUpdateSetting('global_backup_key', globalBackupKey),
    ]);
    showToast('Backup LLM config saved ✓');
  };
  const onSaveRoleOverride = (role: 'supr' | 'code' | 'research' | 'sub') => {
    const titles = { supr: 'Supr Orchestrator', code: 'Coding Agent', research: 'Research Agent', sub: 'Sub-agents' } as const;
    const map = {
      supr: { provider: suprProvider, key: suprKey, model: suprModel, url: suprUrl, prefix: 'supr' },
      code: { provider: codeProvider, key: codeKey, model: codeModel, url: codeUrl, prefix: 'code' },
      research: { provider: researchProvider, key: researchKey, model: researchModel, url: researchUrl, prefix: 'research' },
      sub: { provider: subProvider, key: subKey, model: subModel, url: subUrl, prefix: 'sub' },
    } as const;
    const r = map[role];
    void Promise.all([
      handleUpdateSetting(`llm_provider_${r.prefix}`, r.provider),
      handleUpdateSetting(`llm_key_${r.prefix}`, r.key),
      handleUpdateSetting(`llm_model_${r.prefix}`, r.model),
      handleUpdateSetting(`llm_url_${r.prefix}`, r.url),
    ]);
    showToast(`${titles[role]} override saved ✓`);
  };

  return (
    <div className="flex-1 md:ml-64 flex flex-col min-h-screen bg-surface-container overflow-hidden relative">
      <TopNav title="Settings" />

      {toastMessage && (
        <div className="fixed bottom-8 right-8 bg-surface-container-high border-4 border-primary p-4 z-50 neo-shadow font-headline font-bold uppercase text-sm animate-bounce">
          {toastMessage}
        </div>
      )}


      <main className="flex-1 overflow-y-auto max-w-7xl mx-auto w-full p-4 md:p-8 flex flex-col md:flex-row gap-8">
        {/* Settings Vertical Nav */}
        <aside className="w-full md:w-64 flex-shrink-0 flex flex-col gap-2 border-r-0 md:border-r-4 border-primary pr-0 md:pr-8 mb-8 md:mb-0 sticky top-0 h-fit">
          <h1 className="font-headline text-4xl font-black tracking-tighter uppercase mb-8 pb-4 border-b-4 border-primary">Settings</h1>
          <nav className="flex flex-col gap-2">
            {[
              { name: 'Operating Mode', ref: modeRef },
              { name: 'Permissions', ref: permissionsRef },
              { name: 'LLM Configuration', ref: llmRef },
              { name: 'Theme & Appearance', ref: appearanceRef },
              { name: 'Integrations', ref: integrationsRef },
              { name: 'Memory', ref: memoryRef },
              { name: 'Standards', ref: standardsRef },
              { name: 'Channels & Socials', ref: channelsRef },
              { name: 'Portability', ref: portabilityRef },
            ].map((item) => (
              <button
                key={item.name}
                onClick={() => scrollToSection(item.name, item.ref)}
                className={`font-body font-bold uppercase text-sm p-4 neo-border flex justify-between items-center group transition-all ${
                  activeSection === item.name
                    ? 'bg-primary text-on-primary neo-shadow translate-x-[2px] translate-y-[2px]'
                    : 'bg-surface text-primary hover:bg-surface-container'
                }`}
              >
                {item.name}
                <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">chevron_right</span>
              </button>
            ))}
          </nav>
        </aside>

        {/* Settings Content Area */}
        <section className="flex-1 flex flex-col gap-12 pb-20">

          <div ref={modeRef} className="flex flex-col gap-6">
            <div className="border-b-4 border-primary pb-4 mb-4">
              <h2 className="font-headline text-3xl font-black uppercase tracking-tighter">Operating Mode</h2>
              <p className="font-body text-on-surface-variant mt-2">Configure the autonomy level of the system.</p>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {[
                { id: 'guided', name: 'Guided', risk: 'Low', desc: 'System proposes actions, requires explicit user approval for every step.' },
                { id: 'supervisor', name: 'Supervisor', risk: 'Med', desc: 'System executes autonomously within bounded parameters. Escalates exceptions.' },
                { id: 'autonomous', name: 'Autonomous', risk: 'High', desc: 'System operates independently across most tasks. Requires minimal oversight.' },
                { id: 'fully_autonomous', name: 'Fully Autonomous', risk: 'Extreme', desc: 'Unbounded execution. Self-directed goal generation. Use with caution.', danger: true },
              ].map((mode) => (
                <div
                  key={mode.id}
                  onClick={() => handleModeChange(mode.id)}
                  className={`border-4 border-primary p-6 flex flex-col gap-4 relative overflow-hidden group hover:neo-shadow-lg transition-all cursor-pointer ${
                    operatingMode === mode.id
                      ? mode.danger ? 'bg-secondary text-on-error neo-shadow-lg translate-x-[-2px] translate-y-[-2px]' : 'bg-primary-container text-on-primary-container neo-shadow-lg translate-x-[-2px] translate-y-[-2px]'
                      : 'bg-surface'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h3 className={`font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2 ${operatingMode === mode.id && mode.danger ? 'text-on-error' : ''}`}>
                      {mode.name} {operatingMode === mode.id && <span className="material-symbols-outlined">check_circle</span>}
                    </h3>
                    <span className={`text-xs font-bold uppercase px-2 py-1 border-2 border-primary ${
                      mode.risk === 'Extreme' ? 'bg-secondary text-on-error' :
                      mode.risk === 'High' ? 'bg-tertiary text-on-tertiary' :
                      'bg-surface-container-high'
                    }`}>Risk: {mode.risk}</span>
                  </div>
                  <p className="font-body text-sm flex-1">{mode.desc}</p>
                  <div className="mt-4 flex items-center gap-2 font-bold text-sm uppercase">
                    <span className="material-symbols-outlined">{operatingMode === mode.id ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
                    {operatingMode === mode.id ? 'Active Default' : 'Select Mode'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Permissions Hierarchy */}
          <PermissionsSection
            ref={permissionsRef}
            permissionBoundary={permissionBoundary}
            onEnforceTier={async (id) => {
              setPermissionBoundary(id);
              // Going through handleUpdateSetting broadcasts the
              // cross-tab settings sentinel so the chat picks up
              // the new tier without a refresh.
              await handleUpdateSetting('permission_boundary', id, `Enforced ${id} security tier ✓`);
            }}
            dockerAvailable={dockerAvailable}
            dockerLastProbe={dockerLastProbe}
            onDockerProbe={handleDockerProbe}
            remoteExecutionEnabled={remoteExecutionEnabled}
            remoteExecutionHost={remoteExecutionHost}
            onSetRemoteExecutionEnabled={async (value) => {
              setRemoteExecutionEnabled(value);
              await handleUpdateSetting('remote_execution_enabled', value ? 'true' : 'false', `Remote execution ${value ? 'enabled' : 'disabled'}`);
            }}
            onSetRemoteExecutionHost={setRemoteExecutionHost}
            onUpdateSetting={handleUpdateSetting}
          />

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* LLM Configuration Panel */}
          <LLMConfigSection
            ref={llmRef}
            globalMinimaxKey={globalMinimaxKey}
            globalGeminiKey={globalGeminiKey}
            globalOpenaiKey={globalOpenaiKey}
            globalAnthropicKey={globalAnthropicKey}
            globalXaiKey={globalXaiKey}
            globalOpenrouterKey={globalOpenrouterKey}
            globalGroqKey={globalGroqKey}
            globalMistralKey={globalMistralKey}
            globalDeepseekKey={globalDeepseekKey}
            globalBackupKey={globalBackupKey}
            globalBackupUrl={globalBackupUrl}
            globalBackupModel={globalBackupModel}
            globalBackupName={globalBackupName}
            supr={{ provider: suprProvider, key: suprKey, model: suprModel, url: suprUrl }}
            code={{ provider: codeProvider, key: codeKey, model: codeModel, url: codeUrl }}
            research={{ provider: researchProvider, key: researchKey, model: researchModel, url: researchUrl }}
            sub={{ provider: subProvider, key: subKey, model: subModel, url: subUrl }}
            onChangeGlobalKey={onChangeGlobalKey}
            onChangeBackupField={onChangeBackupField}
            onChangeRoleField={onChangeRoleField}
            providerOptions={PROVIDER_OPTIONS}
            modelOptionsForProvider={modelOptionsForProvider}
            onSelectRoleProvider={onSelectRoleProvider}
            onUpdateSetting={handleUpdateSetting}
            onSaveGlobalKey={onSaveGlobalKey}
            onSaveBackupConfig={onSaveBackupConfig}
            onSaveRoleOverride={onSaveRoleOverride}
            defaultMinimaxModel={DEFAULT_MINIMAX_MODEL}
          />

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Theme & Appearance Section */}
          <div ref={appearanceRef} className="flex flex-col gap-6">
            <div className="border-b-4 border-primary pb-4 mb-4">
              <h2 className="font-headline text-3xl font-black uppercase tracking-tighter">Theme & Appearance</h2>
              <p className="font-body text-on-surface-variant mt-2">Morph the entire design system and layout structure with instant preview.</p>
            </div>

            <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4">
              <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2 border-b-2 border-primary pb-2">
                <span className="material-symbols-outlined text-primary">design_services</span> Design.md Profiles
              </h3>
              <p className="font-body text-sm text-on-surface-variant">
                Apply a profile from <span className="font-mono">design/</span>. Profiles are mapped to safe Supr theme and palette tokens, so the interface changes live without rewriting React files.
              </p>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {designProfiles.map(profile => (
                  <button
                    key={profile.id}
                    onClick={() => handleDesignProfileApply(profile.id)}
                    className={`neo-border bg-background p-4 text-left flex flex-col gap-3 hover:bg-surface-container transition-colors ${
                      activeDesignProfile === profile.id ? 'ring-2 ring-primary bg-primary-container text-on-primary-container' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="font-headline font-black uppercase text-sm block">{profile.name}</span>
                        <span className="font-mono text-[10px] uppercase text-on-surface-variant">{profile.file}</span>
                      </div>
                      <span className="bg-surface-container-high border border-outline-variant px-2 py-1 font-headline font-bold uppercase text-[9px]">
                        {profile.mood}
                      </span>
                    </div>
                    <p className="text-xs text-on-surface-variant line-clamp-3">{profile.preview || 'Design profile ready.'}</p>
                    <div className="flex gap-2 text-[10px] font-mono uppercase">
                      <span>theme:{profile.theme}</span>
                      <span>palette:{profile.palette}</span>
                    </div>
                  </button>
                ))}
                {designProfiles.length === 0 && (
                  <div className="neo-border bg-background p-4 text-sm text-on-surface-variant">
                    No design profiles found in <span className="font-mono">design/</span>.
                  </div>
                )}
              </div>
            </div>

            {/* Layout Themes */}
            <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4">
              <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2 border-b-2 border-primary pb-2">
                <span className="material-symbols-outlined text-primary">layers</span> Structural Layout Styles (12 Themes)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {[
                  { id: 'neo-brutalist', name: 'Neo-Brutalist', desc: 'Thick black borders, solid fills, and offset drop shadows. (Default)', icon: 'grid_view' },
                  { id: 'openclaw', name: 'OpenClaw Terminal', desc: 'Retro developer monospace hacker layout with scanlines and green font glows.', icon: 'terminal' },
                  { id: 'dark-saas-hero-with-liquid-glass', name: 'Hermes Cybernetic', desc: 'Clean dark cyber dashboard with compact borders and subtle cyan tech halos.', icon: 'developer_board' },
                  { id: 'aurora-ui', name: 'Aurora UI', desc: 'Ethereal glowing layout with mesh gradients and vibrant northern light aesthetics.', icon: 'lens_blur' },
                  { id: 'futuristic-ui-glassmorphism', name: 'Futuristic Glass', desc: 'Deep background blur layers, bright cyan highlights, and pure dark depths.', icon: 'blur_on' },
                  { id: '8-bit-retro-terminal', name: 'Phosphor CRT', desc: 'Monochrome glowing green grid layout with curved cathode screen flicker.', icon: 'monitor' },
                  { id: 'cyber-tribal', name: 'Neon Cyberpunk', desc: 'Deep purple canvas with hot pink highlights and heavy glowing neon bevels.', icon: 'palette' },
                  { id: 'minimalist-clean', name: 'Minimalist Clean', desc: 'Sleek professional white space design with extremely soft card borders.', icon: 'space_dashboard' },
                  { id: 'notion', name: 'Notion Minimal', desc: 'Hyper-minimal workspace inspired by Notion.', icon: 'description' },
                  { id: 'thevge', name: 'The Verge Aesthetic', desc: 'Bold, brutalist modern magazine style.', icon: 'newspaper' },
                  { id: 'ibm-carbon-enterprise', name: 'IBM Carbon', desc: 'Strict, grid-based enterprise aesthetic.', icon: 'corporate_fare' },
                  { id: 'supr-clean', name: 'Supr Clean', desc: 'Friendly default interface with balanced curves and gentle contrasts.', icon: 'cleaning_services' },
                ].map(theme => (
                  <div
                    key={theme.id}
                    onClick={() => handleThemeChange(theme.id)}
                    className={`p-4 border-2 border-primary bg-background cursor-pointer hover:bg-surface-container transition-all flex flex-col justify-between min-h-[140px] shadow-[2px_2px_0px_0px_var(--color-primary)] ${
                      currentTheme === theme.id ? 'ring-2 ring-primary bg-primary-container text-on-primary-container' : ''
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-headline font-bold text-xs uppercase flex items-center gap-1.5">
                          <span className="material-symbols-outlined text-sm">{theme.icon}</span> {theme.name}
                        </span>
                        {currentTheme === theme.id && <span className="material-symbols-outlined text-sm text-green-600">check_circle</span>}
                      </div>
                      <p className="text-[10px] leading-relaxed text-on-surface-variant">{theme.desc}</p>
                    </div>
                    <span className="text-[8px] font-bold uppercase tracking-wider mt-4">Select Style</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 3-Tone Color Palettes */}
            <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4">
              <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2 border-b-2 border-primary pb-2">
                <span className="material-symbols-outlined text-primary">color_lens</span> Curated 3-Tone Palettes (15 Choices)
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
                {[
                  { id: 'classic', name: 'Classic Supr', c1: '#ffcc00', c2: '#e63b2e', c3: '#0055ff' },
                  { id: 'cyberpunk-neon', name: 'Cyber Neon', c1: '#ff007f', c2: '#00ffff', c3: '#ffe600' },
                  { id: 'nordic-frost', name: 'Nordic Frost', c1: '#1f3a52', c2: '#3b7c80', c3: '#5f7d95' },
                  { id: 'forest-moss', name: 'Forest Moss', c1: '#2d4a22', c2: '#7c683c', c3: '#4a6670' },
                  { id: 'vintage-orange', name: 'Rust Vintage', c1: '#111111', c2: '#d35400', c3: '#2980b9' },
                  { id: 'matrix-digital', name: 'Digital Matrix', c1: '#00ff00', c2: '#008800', c3: '#32cd32' },
                  { id: 'sunset-glow', name: 'Sunset Glow', c1: '#ff4757', c2: '#6c5ce7', c3: '#10ac84' },
                  { id: 'ocean-breeze', name: 'Ocean Breeze', c1: '#0070f3', c2: '#00d2fc', c3: '#f39c12' },
                  { id: 'royal-velvet', name: 'Royal Velvet', c1: '#5f27cd', c2: '#f1c40f', c3: '#ff4757' },
                  { id: 'sakura-pastel', name: 'Sakura Pastel', c1: '#ff7b90', c2: '#a8dadc', c3: '#ffc6ff' },
                  { id: 'minimal-monochrome', name: 'Monochrome', c1: '#000000', c2: '#555555', c3: '#cccccc' },
                  { id: 'desert-cactus', name: 'Desert Cactus', c1: '#4a5c53', c2: '#e07a5f', c3: '#81b29a' },
                  { id: 'corporate-tech', name: 'Corporate Tech', c1: '#1e3a8a', c2: '#0f766e', c3: '#f59e0b' },
                  { id: 'toxic-spill', name: 'Toxic Spill', c1: '#39ff14', c2: '#ff007f', c3: '#ff5e00' },
                  { id: 'warm-autumn', name: 'Warm Autumn', c1: '#6e1a0b', c2: '#d97706', c3: '#92400e' },
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => handlePaletteChange(p.id)}
                    className={`p-2.5 border-2 border-primary bg-background flex flex-col gap-2 hover:bg-surface-container transition-all text-left shadow-[2px_2px_0px_0px_var(--color-primary)] ${
                      currentPalette === p.id ? 'ring-2 ring-primary bg-primary-container text-on-primary-container' : ''
                    }`}
                  >
                    <span className="font-headline font-bold text-[9px] uppercase truncate block">{p.name}</span>
                    <div className="flex gap-1">
                      <span className="w-4 h-4 border border-primary block" style={{ backgroundColor: p.c1 }} title="Primary"></span>
                      <span className="w-4 h-4 border border-primary block" style={{ backgroundColor: p.c2 }} title="Secondary"></span>
                      <span className="w-4 h-4 border border-primary block" style={{ backgroundColor: p.c3 }} title="Tertiary"></span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Integrations Section */}
          <div ref={integrationsRef} className="flex flex-col gap-6">
            <div className="border-b-4 border-primary pb-4 mb-4">
              <h2 className="font-headline text-3xl font-black uppercase tracking-tighter">API & Integrations Credentials</h2>
              <p className="font-body text-on-surface-variant mt-2">Provide keys to run real commands on GitHub, Slack, and Gmail. Optional channels can stay disconnected without blocking core MiniMax-backed agent work.</p>
            </div>

            <div className="border-4 border-primary p-6 bg-surface">
              <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2 border-b-2 border-primary pb-2 mb-4">
                <span className="material-symbols-outlined text-primary">health_and_safety</span> Connector Health
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                {connectorHealth.map(connector => (
                  <div key={connector.id} className="neo-border bg-background p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-headline font-black uppercase text-xs">{connector.name}</span>
                      <span className={`w-2.5 h-2.5 border border-primary rounded-full ${connector.configured ? 'bg-tertiary' : 'bg-surface-variant'}`}></span>
                    </div>
                    <p className="font-mono text-[10px] uppercase text-on-surface-variant">{connector.status}</p>
                    <button
                      onClick={() => handleConnectorTest(connector.id, connector.name)}
                      className="mt-3 w-full border border-primary px-2 py-1 font-headline font-bold uppercase text-[9px] hover:bg-primary hover:text-on-primary"
                    >
                      Test
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-6">

              {/* Composio */}
              <div>
                <label className="block font-headline font-bold uppercase text-primary mb-1 text-xs">Composio API Connection Key</label>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="Composio API Connection Key"
                    value={integrationComposio}
                    onChange={(e) => {
                      setIntegrationComposio(e.target.value);
                      handleUpdateSetting('integrations_composio', e.target.value);
                    }}
                    className="flex-1 bg-background neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="••••••••••••••••••••"
                  />
                  <button
                    onClick={() => handleUpdateSetting('integrations_composio', integrationComposio, 'Composio key updated ✓')}
                    className="bg-primary text-on-primary font-bold uppercase text-xs px-4 neo-border hover:bg-tertiary transition-colors"
                  >Save</button>
                </div>
                <span className="text-[9px] text-on-surface-variant block mt-1">Connects dynamic workspaces, tool schemas, and agent executions via Composio.</span>
              </div>

              {/* Composio Bridge */}
              <div className="border-2 border-primary p-4 bg-background flex flex-col gap-3">
                <h4 className="font-headline font-bold uppercase text-primary text-xs flex items-center gap-2">
                  <span className="material-symbols-outlined text-sm">hub</span> Composio Bridge
                </h4>
                <p className="font-body text-[10px] text-on-surface-variant">
                  The bridge resolves the Composio API key on every call (Settings first, then
                  <code className="font-mono mx-1">process.env.COMPOSIO_API_KEY</code>). Saving here
                  invalidates the provider cache so the next request picks up the new key without
                  a restart.
                </p>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="Composio Bridge API Key"
                    value={integrationComposio}
                    onChange={(e) => setIntegrationComposio(e.target.value)}
                    className="flex-1 bg-surface neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="sk-..."
                  />
                  <button
                    onClick={handleSaveComposioBridge}
                    className="bg-tertiary text-on-tertiary font-bold uppercase text-xs px-4 neo-border hover:bg-primary hover:text-on-primary transition-colors"
                  >Save &amp; Invalidate</button>
                  <button
                    onClick={handleTestComposioBridge}
                    disabled={composioTestResult.state === 'testing'}
                    className="bg-secondary text-on-secondary font-bold uppercase text-xs px-4 neo-border hover:bg-primary hover:text-on-primary transition-colors disabled:opacity-50 flex items-center gap-1"
                    title="Calls listApps() against the live bridge to confirm the key works."
                  >
                    <span className={`material-symbols-outlined text-[14px] ${composioTestResult.state === 'testing' ? 'animate-spin' : ''}`}>
                      {composioTestResult.state === 'testing' ? 'sync' : 'network_check'}
                    </span>
                    {composioTestResult.state === 'testing' ? 'Testing…' : 'Test'}
                  </button>
                </div>
                {composioTestResult.state !== 'idle' && (
                  <div
                    className={`p-2 border-2 font-mono text-[10px] ${
                      composioTestResult.state === 'ok'
                        ? 'border-tertiary bg-tertiary-container text-on-tertiary-container'
                        : composioTestResult.state === 'error'
                          ? 'border-error bg-error-container text-on-error-container'
                          : 'border-primary bg-surface text-on-surface-variant'
                    }`}
                    role="status"
                    aria-live="polite"
                  >
                    {composioTestResult.state === 'ok' && (
                      <>
                        <strong>OK</strong> ({composioTestResult.elapsedMs}ms) — {composioTestResult.appCount} apps reachable
                        {composioTestResult.firstApps && composioTestResult.firstApps.length > 0 && (
                          <span className="block mt-1 opacity-80">
                            e.g. {composioTestResult.firstApps.map((a) => a.name).join(', ')}
                          </span>
                        )}
                      </>
                    )}
                    {composioTestResult.state === 'error' && (
                      <>
                        <strong>Failed</strong> ({composioTestResult.elapsedMs ?? 0}ms) — {composioTestResult.error}
                      </>
                    )}
                    {composioTestResult.state === 'testing' && <span>Calling /api/composio/test…</span>}
                  </div>
                )}
              </div>

              {/* GitHub */}
              <div>
                <label className="block font-headline font-bold uppercase text-primary mb-1 text-xs">GitHub Personal Access Token (PAT)</label>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="GitHub Personal Access Token (PAT)"
                    value={integrationGithub}
                    onChange={(e) => {
                      setIntegrationGithub(e.target.value);
                      handleUpdateSetting('integrations_github', e.target.value);
                    }}
                    className="flex-1 bg-background neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="ghp_••••••••••••••••••••"
                  />
                  <button
                    onClick={() => handleUpdateSetting('integrations_github', integrationGithub, 'GitHub token updated ✓')}
                    className="bg-primary text-on-primary font-bold uppercase text-xs px-4 neo-border hover:bg-tertiary transition-colors"
                  >Save</button>
                </div>
                <span className="text-[9px] text-on-surface-variant block mt-1">Clearance token enabling Supr to pull repos, create issues, and manage task branches. (Coming Soon)</span>
              </div>

              {/* Slack */}
              <div>
                <label className="block font-headline font-bold uppercase text-primary mb-1 text-xs">Slack Webhook URL</label>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="Slack Webhook URL"
                    value={integrationSlack}
                    onChange={(e) => {
                      setIntegrationSlack(e.target.value);
                      handleUpdateSetting('integrations_slack', e.target.value);
                    }}
                    className="flex-1 bg-background neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="https://hooks.slack.com/services/••••••••"
                  />
                  <button
                    onClick={() => handleUpdateSetting('integrations_slack', integrationSlack, 'Slack webhook updated ✓')}
                    className="bg-primary text-on-primary font-bold uppercase text-xs px-4 neo-border hover:bg-tertiary transition-colors"
                  >Save</button>
                </div>
                <span className="text-[9px] text-on-surface-variant block mt-1">Webhooks enabling direct pings to your channels for approval alerts and deployment traces.</span>
              </div>

              {/* Discord */}
              <div>
                <label className="block font-headline font-bold uppercase text-primary mb-1 text-xs">Discord Webhook URL</label>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="Discord Webhook URL"
                    value={integrationDiscord}
                    onChange={(e) => {
                      setIntegrationDiscord(e.target.value);
                      handleUpdateSetting('integrations_discord', e.target.value);
                    }}
                    className="flex-1 bg-background neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="https://discord.com/api/webhooks/..."
                  />
                  <button
                    onClick={() => handleUpdateSetting('integrations_discord', integrationDiscord, 'Discord webhook updated')}
                    className="bg-primary text-on-primary font-bold uppercase text-xs px-4 neo-border hover:bg-tertiary transition-colors"
                  >Save</button>
                </div>
                <span className="text-[9px] text-on-surface-variant block mt-1">Webhook used by the Messaging Gateway for approval, failure, and mission completion notifications.</span>
              </div>

              {/* Gmail */}
              <div>
                <label className="block font-headline font-bold uppercase text-primary mb-1 text-xs">Gmail App Password / Access Code</label>
                <div className="flex gap-2">
                  <input
                    type="password" aria-label="Gmail App Password / Access Code"
                    value={integrationGmail}
                    onChange={(e) => {
                      setIntegrationGmail(e.target.value);
                      handleUpdateSetting('integrations_gmail', e.target.value);
                    }}
                    className="flex-1 bg-background neo-border p-2 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="•••• •••• •••• ••••"
                  />
                  <button
                    onClick={() => handleUpdateSetting('integrations_gmail', integrationGmail, 'Gmail credential updated ✓')}
                    className="bg-primary text-on-primary font-bold uppercase text-xs px-4 neo-border hover:bg-tertiary transition-colors"
                  >Save</button>
                </div>
                <span className="text-[9px] text-on-surface-variant block mt-1">Required App Password enabling direct SMTP/IMAP scans for pulling messages and automated notifications. (Coming Soon)</span>
              </div>

            </div>
          </div>

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Memory Banks */}
      <MemorySection
        ref={memoryRef}
        memoryItems={memoryItems}
        showMemoryModal={showMemoryModal}
        activeMemoryBank={activeMemoryBank}
        newKey={newKey}
        newValue={newValue}
        newImportance={newImportance}
        memorySearch={memorySearch}
        showPinnedOnly={showPinnedOnly}
        visibleMemoryItems={visibleMemoryItems}
        onOpenBank={(name) => {
          setActiveMemoryBank(name);
          setShowMemoryModal(true);
        }}
        onCloseModal={() => setShowMemoryModal(false)}
        onChangeNewKey={setNewKey}
        onChangeNewValue={setNewValue}
        onChangeNewImportance={setNewImportance}
        onChangeSearch={setMemorySearch}
        onTogglePinnedOnly={() => setShowPinnedOnly((prev) => !prev)}
        onSubmitMemory={handleAddMemory}
        onPurgeBank={handlePurgeBank}
        onPinItem={(id, pinned) => handleMemoryReview(id, { pinned })}
        onReviewItem={(id) => handleMemoryReview(id, { reviewed: true })}
      />

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Operational Standards */}
          <StandardsSection
            ref={standardsRef}
            onUpdateSetting={handleUpdateSetting}
          />

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Channels & Socials Section */}
          <div ref={channelsRef} className="flex flex-col gap-6">
            <div className="border-b-4 border-primary pb-4 mb-4">
              <h2 className="font-headline text-3xl font-black uppercase tracking-tighter">Channels & Socials</h2>
              <p className="font-body text-on-surface-variant mt-2">Configure notification triggers, social hooks, and chat automation bots.</p>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {/* Telegram Channel Connector */}
              <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4 relative overflow-hidden group">
                <div className="flex justify-between items-center border-b-2 border-primary pb-3">
                  <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">telegram</span> Telegram Chatbot Connection
                  </h3>
                  <button
                    onClick={() => handleToggleChannel('telegram', telegramEnabled, 'Telegram Channel')}
                    className={`text-xs font-bold uppercase px-3 py-1 border-2 border-primary transition-all ${
                      telegramEnabled ? 'bg-primary text-on-primary neo-shadow' : 'bg-surface-dim text-on-surface-variant'
                    }`}
                  >
                    {telegramEnabled ? 'Connected ✓' : 'Disconnected'}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                  <div>
                    <label className="block font-headline font-bold uppercase text-primary mb-2 text-xs">Bot Token</label>
                    <input
                      type="password" aria-label="Bot Token"
                      value={telegramToken}
                      onChange={(e) => {
                        setTelegramToken(e.target.value);
                        handleUpdateSetting('telegram_token', e.target.value);
                      }}
                      className="w-full bg-background neo-border p-3 font-mono text-xs focus:outline-none focus:border-tertiary"
                      placeholder="e.g. 123456789:ABCdefGhIJK..."
                    />
                  </div>
                  <div>
                    <label className="block font-headline font-bold uppercase text-primary mb-2 text-xs">Chat ID / Group Channel</label>
                    <input
                      type="text"
                      value={telegramChatId}
                      onChange={(e) => {
                        setTelegramChatId(e.target.value);
                        handleUpdateSetting('telegram_chat_id', e.target.value);
                      }}
                      className="w-full bg-background neo-border p-3 font-mono text-xs focus:outline-none focus:border-tertiary"
                      placeholder="e.g. -100123456789"
                    />
                  </div>
                  <div>
                    <label className="block font-headline font-bold uppercase text-primary mb-2 text-xs">Webhook Secret</label>
                    <input
                      type="password" aria-label="Webhook Secret"
                      value={telegramWebhookSecret}
                      onChange={(e) => {
                        setTelegramWebhookSecret(e.target.value);
                        handleUpdateSetting('telegram_webhook_secret', e.target.value);
                      }}
                      className="w-full bg-background neo-border p-3 font-mono text-xs focus:outline-none focus:border-tertiary"
                      placeholder="e.g. MySecretToken123"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center mt-4 flex-wrap gap-4">
                  <p className="font-body text-xs text-on-surface-variant max-w-md">
                    Inbound: Supr rejects any POST that does not include the matching
                    <code className="mx-1 font-mono text-primary">X-Telegram-Bot-Api-Secret-Token</code>
                    header. Generate the secret in BotFather and paste the same value here.
                    Outbound: messages are currently queued locally (the Telegram
                    send adapter is planned; check the README "Telegram outbound"
                    note for the current ship status).
                  </p>
                </div>
              </div>

              {/* Twitter/X Connector */}
              <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4 relative overflow-hidden group">
                <div className="flex justify-between items-center border-b-2 border-primary pb-3">
                  <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">share</span> Twitter / X Broadcast Connection
                  </h3>
                  {/* Toggle is disabled: the X/Twitter integration is
                      planned but not yet implemented. Showing a clickable
                      "Connected" toggle would be a false claim. */}
                  <button
                    disabled
                    aria-disabled="true"
                    title="X/Twitter integration is planned; the toggle is disabled until the delivery adapter ships."
                    className="text-xs font-bold uppercase px-3 py-1 border-2 border-primary bg-surface-dim text-on-surface-variant opacity-60 cursor-not-allowed"
                  >
                    Coming Soon
                  </button>
                </div>

                <div>
                  <label className="block font-headline font-bold uppercase text-primary mb-2 text-xs">Linked X Account Handle</label>
                  <input
                    type="text"
                    value={twitterHandle}
                    onChange={(e) => {
                      setTwitterHandle(e.target.value);
                      handleUpdateSetting('twitter_handle', e.target.value);
                    }}
                    className="w-full bg-background neo-border p-3 font-mono text-xs focus:outline-none focus:border-tertiary"
                    placeholder="@supr_orchestrator"
                  />
                </div>

                <div className="flex justify-between items-center flex-wrap gap-4 mt-2">
                  <p className="font-body text-xs text-on-surface-variant max-w-lg">Allows research agents to draft or directly post scheduled social media announcements and trend analysis briefs. (Coming Soon)</p>
                </div>
              </div>

              {/* Email Broadcast Connector */}
              <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4 relative overflow-hidden group">
                <div className="flex justify-between items-center border-b-2 border-primary pb-3">
                  <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">mail</span> Email Alerts Hook
                  </h3>
                  {/* Toggle disabled: the email delivery adapter is
                      planned but not implemented. Surfacing an "Active"
                      toggle would misrepresent the feature. */}
                  <button
                    disabled
                    aria-disabled="true"
                    title="Email delivery is planned; the toggle is disabled until the SMTP/send adapter ships."
                    className="text-xs font-bold uppercase px-3 py-1 border-2 border-primary bg-surface-dim text-on-surface-variant opacity-60 cursor-not-allowed"
                  >
                    Coming Soon
                  </button>
                </div>
                <p className="font-body text-xs text-on-surface-variant">Sends automated daily executive brief summaries, critical diagnostic console alerts, and QA report handoffs directly to key stakeholders. (Coming Soon)</p>
              </div>

              {/* Slack Connector */}
              <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4 relative overflow-hidden group">
                <div className="flex justify-between items-center border-b-2 border-primary pb-3">
                  <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">chat_bubble</span> Slack Webhook hook
                  </h3>
                  <button
                    onClick={() => handleToggleChannel('slack', slackEnabled, 'Slack webhook channel')}
                    className={`text-xs font-bold uppercase px-3 py-1 border-2 border-primary transition-all ${
                      slackEnabled ? 'bg-primary text-on-primary neo-shadow' : 'bg-surface-dim text-on-surface-variant'
                    }`}
                  >
                    {slackEnabled ? 'Active ✓' : 'Inactive'}
                  </button>
                </div>
                <p className="font-body text-xs text-on-surface-variant">Triggers notification pings to designated Slack channels when agent sandbox tasks fail or when manual overrides are intercepted.</p>
              </div>

              {/* Discord Connector */}
              <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4 relative overflow-hidden group">
                <div className="flex justify-between items-center border-b-2 border-primary pb-3">
                  <h3 className="font-headline text-xl font-bold uppercase tracking-tight flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">forum</span> Discord Webhook Hook
                  </h3>
                  <button
                    onClick={() => handleToggleChannel('discord', discordEnabled, 'Discord webhook channel')}
                    className={`text-xs font-bold uppercase px-3 py-1 border-2 border-primary transition-all ${
                      discordEnabled ? 'bg-primary text-on-primary neo-shadow' : 'bg-surface-dim text-on-surface-variant'
                    }`}
                  >
                    {discordEnabled ? 'Active âœ“' : 'Inactive'}
                  </button>
                </div>
                <p className="font-body text-xs text-on-surface-variant">Receives governed Discord webhook commands and sends approval/completion notifications through the Messaging Gateway.</p>
              </div>

            </div>
          </div>

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Portability Section */}
          <PortabilitySection
            ref={portabilityRef}
            lastBackupAt={lastBackupAt}
            isBackingUp={isBackingUp}
            onExport={handleExportDatabase}
            importStatus={importStatus}
            importBundle={importBundle}
            collisions={collisions}
            confirmOverwrite={confirmOverwrite}
            importSummary={importSummary}
            onFileSelect={handleImportFileSelect}
            onExecuteImport={handleExecuteImport}
            onCancelImport={() => {
              setImportStatus("idle");
              setImportBundle(null);
              setCollisions([]);
              setConfirmOverwrite(false);
            }}
            onClearSummary={() => setImportSummary(null)}
            onConfirmOverwriteChange={setConfirmOverwrite}
          />

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Skill Lessons — self-improving feedback loop */}
          <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4">
            <div className="flex justify-between items-center border-b-2 border-primary pb-3">
              <h2 className="font-headline text-xl font-bold uppercase tracking-tight">
                Skill Lessons (.lessons.md)
              </h2>
            </div>
            <p className="font-body text-xs text-on-surface-variant">
              Every skill invocation records a lesson at <code className="font-mono">.agents/skills/&lt;name&gt;/.lessons.md</code>.
              Past lessons are injected into the next invocation&apos;s prompt so the agent
              adapts its behavior based on prior runs. Pinned entries survive garbage collection.
            </p>
            <SkillsLessonsPanel />
          </div>

          <div className="w-full h-4 bg-primary opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, #1a1a1a 10px, #1a1a1a 20px)" }}></div>

          {/* Context Compaction tuning */}
          <div className="border-4 border-primary p-6 bg-surface flex flex-col gap-4">
            <div className="flex justify-between items-center border-b-2 border-primary pb-3">
              <h2 className="font-headline text-xl font-bold uppercase tracking-tight">
                Context Compaction
              </h2>
            </div>
            <CompactionPanel />
          </div>

        </section>
      </main>
    </div>
  );
}
