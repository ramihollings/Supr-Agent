"use client";

import { useState, useEffect, useRef } from 'react';
import { fetchMissionState } from '@/app/actions';
import { Mission, Artifact, RunEvent } from '@/types';
import { LiveCloakBrowser, useCloakBrowser } from '@/components/LiveCloakBrowser';

type SearchLogEntry = {
  id: number;
  type: 'search' | 'navigate' | 'extract' | 'supr';
  content: string;
};

type BrowseState = 'idle' | 'searching' | 'browsing' | 'extracting' | 'done';
type ResearchSourceCard = {
  id: string;
  url: string;
  domain: string;
  title: string;
  snippets: string[];
  confidence: 'low' | 'medium' | 'high';
};

export default function ResearchPage() {
  const [browseState, setBrowseState] = useState<BrowseState>('idle');
  const [currentUrl, setCurrentUrl] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchLog, setSearchLog] = useState<SearchLogEntry[]>([]);
  const [extractedData, setExtractedData] = useState<string[]>([]);
  const [sourceCards, setSourceCards] = useState<ResearchSourceCard[]>([]);
  const [completionStatus, setCompletionStatus] = useState<'idle' | 'complete' | 'partial'>('idle');
  const [isRunning, setIsRunning] = useState(false);
  const [navigateUrl, setNavigateUrl] = useState('');
  const [mission, setMission] = useState<Mission | null>(null);

  const cloak = useCloakBrowser();
  
  // Bridge state: Live Code view from the Code Workspace
  const [codeArtifacts, setCodeArtifacts] = useState<Artifact[]>([]);
  const [selectedCodeFile, setSelectedCodeFile] = useState<Artifact | null>(null);
  const [codeTriageStatus, setCodeTriageStatus] = useState<string>('Pending Research Context');
  const logCounterRef = useRef(0);
  const nextLogId = () => Date.now() + (logCounterRef.current++ % 1000) / 1000;
  const researchEvents: RunEvent[] = searchLog.map((line) => ({
    id: String(line.id),
    kind: line.type === 'extract' ? 'artifact' : line.type === 'supr' ? 'system' : 'tool',
    title: line.type === 'extract' ? 'Extraction result' : line.type === 'navigate' ? 'Browser step' : 'Research event',
    detail: line.content,
    actor: line.type === 'supr' ? 'Supr' : 'Research Agent',
    timestamp: new Date(line.id).toISOString(),
    status: line.content.includes('[ERROR]') ? 'failed' : line.content.includes('Extracted') ? 'succeeded' : isRunning ? 'running' : 'succeeded',
    evidence: line.type === 'extract' ? [{ id: `${line.id}-source`, label: 'research-stream', durable: true }] : [],
  }));
  const evidenceSources = [
    ...sourceCards.map((source) => ({
      id: source.id,
      title: source.title,
      detail: `${source.domain} / ${source.snippets.length} snippet(s) captured.`,
      sourceType: 'web' as const,
      confidence: source.confidence,
      href: source.url,
    })),
    ...extractedData.map((finding, index) => ({
      id: `finding-${index}`,
      title: `Signal #${index + 1}`,
      detail: finding,
      sourceType: 'web' as const,
      confidence: 'medium' as const,
      href: currentUrl || undefined,
    })),
    ...codeArtifacts.map((artifact) => ({
      id: artifact.id,
      title: artifact.filename,
      detail: `${artifact.type} artifact available to the code workspace.`,
      sourceType: 'artifact' as const,
      confidence: 'high' as const,
    })),
  ];

  const fetchState = async () => {
    const activeMission = await fetchMissionState();
    if (activeMission) {
      setMission(activeMission);
      
      // Filter out code files written by the Coding Agent
      const codeFiles = activeMission.artifacts?.filter(a => a.filename.endsWith('.py') || a.filename.endsWith('.json')) || [];
      setCodeArtifacts(codeFiles);

      // Check if code has the fallback fix to update status
      const clusterCode = activeMission.artifacts?.find(a => a.filename === 'feedback_clusters.py')?.content || '';
      if (clusterCode.includes('embedding') && (clusterCode.includes('not in') || clusterCode.includes('not'))) {
        setCodeTriageStatus('Passed Verification ✓');
      } else {
        const hasResearch = (activeMission.artifacts?.filter(a => a.filename.startsWith('research_')) || []).length > 0;
        setCodeTriageStatus(hasResearch ? 'Guidance Dispatched - Run Test' : 'Blocked by AssertionError (t2)');
      }
    }
  };

  useEffect(() => {
    fetchState();
    // Poll state every 4 seconds to pick up live edits from the Code Workspace!
    const interval = setInterval(fetchState, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleStartResearch = async () => {
    if (isRunning || !searchQuery.trim()) return;
    setIsRunning(true);
    setBrowseState('searching');
    setExtractedData([]);
    setSourceCards([]);
    setCompletionStatus('idle');

    setSearchLog(prev => [...prev, { id: nextLogId(), type: 'supr', content: `[SUPR] Delegating research task to Research Agent: "${searchQuery}"` }]);

    try {
      const response = await fetch('/api/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery, missionId: mission?.id }),
      });

      if (!response.body) throw new Error('No response stream.');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const msg = JSON.parse(line);

            if (msg.type === 'status') {
              // Update the browser chrome and crawl log based on phase
              if (msg.phase === 'searching') {
                setBrowseState('searching');
                const slug = searchQuery.toLowerCase().replace(/\s+/g, '-');
                setCurrentUrl(`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`);
              } else if (msg.phase === 'browsing') {
                setBrowseState('browsing');
              } else if (msg.phase === 'extracting' || msg.phase === 'generating') {
                setBrowseState('extracting');
              }
              setSearchLog(prev => [...prev, { id: nextLogId(), type: 'navigate', content: msg.content }]);
            }

            if (msg.type === 'result') {
              setExtractedData(msg.findings || []);
              setSourceCards(msg.sources || []);
              setCompletionStatus(msg.completionStatus || (msg.sources?.length ? 'complete' : 'partial'));
              if (msg.url) setCurrentUrl(msg.url);
              setBrowseState('done');
              setSearchLog(prev => [
                ...prev,
                { id: nextLogId(), type: 'extract', content: `[RESEARCH AGENT] Extracted ${msg.findings?.length || 0} intelligence signals from ${msg.sources?.length || 0} source(s).` },
                { id: nextLogId(), type: 'supr', content: msg.completionStatus === 'complete' ? `[SUPR] Source-backed brief saved to SQLite: ${msg.filename}.` : `[SUPR] Partial brief saved to SQLite: ${msg.filename}. Source evidence required before verified handoff.` },
              ]);
              // Drive the live CloakBrowser to the strongest source URL
              // so the viewport reflects exactly what the agent saw.
              const firstSource = Array.isArray(msg.sources) && msg.sources.length > 0
                ? msg.sources[0]?.url
                : null;
              if (typeof msg.url === 'string' && msg.url.startsWith('http') && msg.url !== 'no-source://research-agent/') {
                cloak.actions.navigate(msg.url);
              } else if (firstSource && firstSource.startsWith('http')) {
                cloak.actions.navigate(firstSource);
              }
              // Refresh mission state to pick up new artifacts
              await fetchState();
            }

            if (msg.type === 'error') {
              setSearchLog(prev => [...prev, { id: nextLogId(), type: 'supr', content: `[ERROR] ${msg.content}` }]);
              setBrowseState('done');
            }
          } catch (parseErr) {
            // Skip malformed lines
          }
        }
      }
    } catch (err: any) {
      setSearchLog(prev => [...prev, { id: nextLogId(), type: 'supr', content: `[ERROR] Research pipeline failed: ${err.message}` }]);
      setBrowseState('done');
    }

    setIsRunning(false);
  };


  return (
    <div className="flex-1 md:ml-64 flex flex-col h-screen overflow-hidden bg-surface-container">
      {/* Header */}
      <header className="flex-none h-16 border-b-4 border-primary bg-background flex justify-between items-center px-4 lg:px-6">
        <div className="flex items-center space-x-4">
          <span className="material-symbols-outlined text-primary text-2xl">travel_explore</span>
          <h2 className="font-headline font-bold text-lg md:text-xl uppercase tracking-tight">Research Workspace</h2>
        </div>
        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center space-x-2 bg-surface-container-high px-3 py-1 border-2 border-primary">
            <span className={`w-3 h-3 border border-primary ${browseState === 'done' ? 'bg-tertiary' : browseState === 'idle' ? 'bg-outline' : 'bg-primary-fixed animate-pulse'}`}></span>
            <span className="font-body font-bold text-sm uppercase">
              Research Agent {browseState === 'done' ? '✓ Complete' : browseState === 'idle' ? 'Standby' : 'Scraping...'}
            </span>
          </div>
        </div>
      </header>

      {/* Split Pane */}
      <div className="flex-1 flex overflow-hidden w-full">

        {/* Left Panel: Research Query & Findings */}
        <aside className="w-72 flex-none border-r-4 border-primary bg-background hidden md:flex flex-col">
          <div className="p-3 border-b-4 border-primary bg-surface-variant shrink-0">
            <span className="font-headline font-bold uppercase text-sm tracking-widest">Research Query</span>
          </div>
          <div className="p-4 border-b-4 border-primary shrink-0">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="e.g. export latency solutions"
              disabled={isRunning}
              className="w-full bg-surface neo-border px-3 py-2 font-body text-xs focus:outline-none focus:border-tertiary disabled:opacity-50"
            />
            <button
              onClick={handleStartResearch}
              disabled={isRunning || !searchQuery.trim()}
              className="w-full mt-3 bg-primary text-on-primary font-headline font-bold uppercase py-2 neo-border neo-shadow text-xs hover:bg-tertiary hover:text-on-tertiary active:translate-x-1 active:translate-y-1 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">search</span>
              Begin Web Crawl
            </button>

            <div className="mt-3 pt-3 border-t-2 border-outline-variant">
              <label className="block font-headline font-bold uppercase text-[10px] text-on-surface-variant tracking-widest mb-1">
                Drive CloakBrowser
              </label>
              <div className="flex gap-1">
                <input
                  type="text"
                  value={navigateUrl}
                  onChange={(e) => setNavigateUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (navigateUrl.trim()) {
                        cloak.actions.navigate(navigateUrl.trim());
                        setNavigateUrl('');
                      }
                    }
                  }}
                  placeholder="https://example.com"
                  className="flex-1 min-w-0 bg-surface neo-border px-2 py-2 font-mono text-[11px] focus:outline-none focus:border-tertiary"
                />
                <button
                  onClick={() => {
                    if (navigateUrl.trim()) {
                      cloak.actions.navigate(navigateUrl.trim());
                      setNavigateUrl('');
                    }
                  }}
                  disabled={!navigateUrl.trim() || cloak.isNavigating}
                  className="bg-tertiary text-on-tertiary font-headline font-bold uppercase px-2 neo-border neo-shadow text-[10px] hover:bg-primary hover:text-on-primary active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-50 flex items-center gap-1"
                  title="Navigate CloakBrowser to URL"
                >
                  <span className="material-symbols-outlined text-[14px]">travel_explore</span>
                  Go
                </button>
              </div>
              {cloak.activePage && cloak.activePage.url !== 'about:blank' && (
                <p className="mt-1.5 font-mono text-[9px] text-on-surface-variant break-all">
                  Live: {cloak.activePage.finalUrl || cloak.activePage.url}
                </p>
              )}
            </div>
          </div>

          {/* Extracted Findings */}
          <div className="p-3 border-b-4 border-primary bg-surface-variant shrink-0">
            <span className="font-headline font-bold uppercase text-sm tracking-widest">Extracted Specs</span>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2.5 bg-surface-container-low">
            {extractedData.length === 0 && (
              <p className="text-on-surface-variant text-[10px] font-body font-semibold uppercase italic text-center p-3">No specs extracted. Run a web crawl.</p>
            )}
            {extractedData.map((finding, i) => (
              <div key={i} className="p-2.5 border-l-4 border-tertiary bg-background neo-border font-body text-xs shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] leading-relaxed">
                <strong>Signal #{i + 1}:</strong> {finding}
              </div>
            ))}
          </div>

          {/* Active Sandbox Code Drawer (Bridge to Code Workspace!) */}
          <div className="h-1/3 border-t-4 border-primary flex flex-col shrink-0">
            <div className="p-2 border-b-4 border-primary bg-secondary text-on-secondary flex items-center justify-between">
              <span className="font-headline font-bold uppercase text-xs flex items-center gap-1">
                <span className="material-symbols-outlined text-sm">code</span>
                Sandbox Code Sync
              </span>
              <span className="bg-secondary-container text-on-secondary-container px-1.5 py-0.5 text-[8px] font-bold uppercase neo-border">Live Link</span>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2 bg-surface-container-high">
              <div className="mb-2 p-1.5 bg-background border border-primary text-[9px] font-mono leading-normal">
                <strong>Triage Status:</strong> <span className={codeTriageStatus.includes('Passed') ? 'text-green-600 font-bold' : 'text-red-500 font-bold animate-pulse'}>{codeTriageStatus}</span>
              </div>
              {codeArtifacts.map(art => (
                <div 
                  key={art.id}
                  onClick={() => setSelectedCodeFile(art)}
                  className="p-1.5 border-2 border-primary bg-background hover:bg-secondary-container hover:text-on-secondary-container cursor-pointer transition-colors shadow-[1px_1px_0px_0px_rgba(26,26,26,1)] flex items-center gap-2"
                >
                  <span className="material-symbols-outlined text-xs text-primary">data_object</span>
                  <span className="font-body text-[9px] font-bold uppercase truncate">{art.filename}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Center: Live CloakBrowser Viewport */}
        <LiveCloakBrowser
          pages={cloak.pages}
          activePageId={cloak.activePageId}
          cloakPath={cloak.cloakPath}
          isNavigating={cloak.isNavigating}
          canGoBack={cloak.canGoBack}
          canGoForward={cloak.canGoForward}
          onBack={cloak.actions.goBack}
          onForward={cloak.actions.goForward}
          onReload={cloak.actions.reload}
          onHome={cloak.actions.goHome}
          onSelect={cloak.actions.setActivePageId}
          onClose={cloak.actions.closePage}
        />

        {/* Right Panel: Search Log */}
        <aside className="w-80 lg:w-96 flex-none border-l-4 border-primary bg-background hidden lg:flex flex-col">
          <div className="p-3 border-b-4 border-primary bg-surface-variant flex justify-between items-center shrink-0">
            <span className="font-headline font-bold uppercase text-sm tracking-widest flex items-center gap-2 text-primary">
              <span className="material-symbols-outlined text-[18px]">list_alt</span>
              Crawl Event Log
            </span>
            <button
              onClick={() => setSearchLog([])}
              className="text-xs font-bold uppercase hover:text-error transition-colors"
            >Clear</button>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 bg-black text-amber-400 font-mono text-xs leading-loose">
            {searchLog.length === 0 && (
              <div className="text-amber-800">Crawl log ready. Run a research query to see agent browser logs.</div>
            )}
            {searchLog.map(line => (
              <div key={line.id} className={`mb-2 ${
                line.type === 'search' ? 'text-blue-400 font-bold' :
                line.type === 'navigate' ? 'text-purple-400' :
                line.type === 'extract' ? 'text-green-400 font-bold' :
                line.type === 'supr' ? 'text-amber-300 font-bold' : ''
              }`}>
                {line.type === 'search' && <span className="mr-1">🔍</span>}
                {line.type === 'navigate' && <span className="mr-1">→</span>}
                {line.type === 'extract' && <span className="mr-1">📋</span>}
                {line.content}
              </div>
            ))}
          </div>

          {/* Supr Guidance */}
          <div className="h-1/4 border-t-4 border-primary bg-background flex flex-col shrink-0">
            <div className="p-2 border-b-4 border-primary bg-primary-fixed flex items-center justify-between">
              <span className="font-headline font-bold uppercase text-sm flex items-center gap-2 text-primary">
                <span className="material-symbols-outlined text-[18px]">psychology</span> Supr Guidance
              </span>
              <span className={`text-xs font-bold uppercase px-2 py-0.5 border-2 border-primary ${
                browseState === 'done' ? 'bg-tertiary text-on-tertiary' :
                browseState === 'idle' ? 'bg-background text-primary' :
                'bg-secondary text-on-error animate-pulse'
              }`}>
                {browseState === 'idle' ? 'Standby' : browseState === 'done' ? 'Ready' : 'Monitoring'}
              </span>
            </div>
            <div className="p-2 border-b-2 border-primary bg-surface-container flex items-center gap-2 text-[10px] font-mono">
              <span className="material-symbols-outlined text-[12px] text-primary">travel_explore</span>
              <span className="font-bold uppercase text-primary">CloakBrowser</span>
              {cloak.cloakPath ? (
                <span className="text-tertiary" title={cloak.cloakPath}>
                  ready · {cloak.cloakPath.split('/').pop() || cloak.cloakPath}
                </span>
              ) : (
                <span className="text-error" title="Set CLOAKBROWSER_PATH to enable live navigation">
                  CLOAKBROWSER_PATH not set
                </span>
              )}
            </div>
            <div className="p-4 flex-1 overflow-y-auto custom-scrollbar text-xs">
              {browseState === 'idle' && (
                <p className="text-on-surface-variant leading-relaxed">Supr is monitoring the Research Agent. When competitor specs are saved, they are immediately synchronized to the Coding Agent sandbox.</p>
              )}
              {browseState !== 'idle' && browseState !== 'done' && (
                <p className="text-on-surface-variant leading-relaxed animate-pulse text-secondary font-bold">Research Agent is actively scraping targets. Awaiting data extraction...</p>
              )}
            {browseState === 'done' && (
                <p className="text-on-surface-variant leading-relaxed">
                  {completionStatus === 'complete'
                    ? 'Research complete with source-backed evidence. The Coding Agent workspace can now use the brief.'
                    : 'Research finished as partial. Source evidence is missing, so Supr will treat this as unverified context.'}
                </p>
              )}
            </div>
          </div>

          <div className="border-t-4 border-primary p-3 bg-surface-container-low">
            <div className="font-headline font-black uppercase text-sm text-primary border-b-2 border-primary pb-2 mb-3">Research Evidence</div>
            <div className="space-y-2">
              {evidenceSources.length === 0 ? (
                <p className="font-body text-xs text-on-surface-variant">Run a research query to collect sources, signals, and durable artifacts.</p>
              ) : (
                evidenceSources.map((source) => (
              <div key={source.id} className="bg-surface border border-outline-variant rounded p-2">
                <p className="font-body text-xs font-semibold">{source.title}</p>
                {('href' in source && source.href) ? <p className="font-mono text-[10px] text-on-surface-variant break-all">{source.href}</p> : null}
                <p className="font-body text-[10px] text-on-surface-variant mt-1">{source.detail}</p>
              </div>
                ))
              )}
            </div>
          </div>
        </aside>
      </div>

      {/* Code Viewer popup overlay */}
      {selectedCodeFile && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-background border-4 border-primary max-w-2xl w-full p-6 neo-shadow relative flex flex-col max-h-[85vh]">
            <button 
              onClick={() => setSelectedCodeFile(null)}
              className="absolute top-4 right-4 text-primary font-bold hover:text-error text-xl font-headline"
            >✕</button>
            <h3 className="font-headline text-xl font-black uppercase text-primary border-b-4 border-primary pb-3 mb-4 flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary">code</span>
              Sandbox Code: {selectedCodeFile.filename}
            </h3>
            <div className="flex-1 overflow-y-auto custom-scrollbar font-mono text-xs bg-black text-green-400 p-4 neo-border whitespace-pre-wrap leading-relaxed">
              {selectedCodeFile.content}
            </div>
            <div className="mt-4 flex justify-end">
              <button 
                onClick={() => setSelectedCodeFile(null)}
                className="bg-primary text-on-primary font-headline font-bold uppercase px-4 py-2 neo-border neo-shadow text-xs hover:bg-tertiary hover:text-on-tertiary"
              >Close Viewer</button>
            </div>
          </div>
        </div>
      )}

      <footer className="flex-none h-8 border-t-4 border-primary flex items-center px-4 justify-between font-mono text-xs bg-primary text-on-primary shrink-0">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="material-symbols-outlined text-[14px]">travel_explore</span>
            Research Engine Active
          </span>
        </div>
        <span className="text-[10px] font-bold uppercase">Supr Research V1.2</span>
      </footer>
    </div>
  );
}
